import json
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

MINT = "Fksnpd6PPR87sCUXe2F8xqJgzAVnRBXfjsVxYZqqpump"
STARTING_SOL = 1.0
TRADE_SIZE_SOL = 0.01
TAKE_PROFIT_PCT = 30.0
STOP_LOSS_PCT = 15.0
POLL_SECONDS = 15
STATE_FILE = Path("paper_state.json")

# Bir DexScreener token sayfası eşleşmesi varsa SOL cinsinden yaklaşık fiyat.
# Bu yalnızca gözlem/simülasyon içindir; gerçek emir gönderilmez.
URL = f"https://api.dexscreener.com/latest/dex/tokens/{MINT}"

def load_state():
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {
        "cash_sol": STARTING_SOL,
        "position_tokens": 0.0,
        "entry_price_usd": None,
        "entry_cost_sol": 0.0,
        "trades": [],
        "last_price_usd": None
    }

def save_state(state):
    STATE_FILE.write_text(json.dumps(state, indent=2))

def get_price():
    response = requests.get(URL, timeout=15)
    response.raise_for_status()
    data = response.json()
    pairs = data.get("pairs") or []
    if not pairs:
        return None, "DexScreener bu mint için henüz fiyat/pair verisi döndürmedi."
    # Solana pair'leri içinde likiditesi en yüksek olanı seç.
    pairs = [p for p in pairs if p.get("chainId") == "solana"]
    if not pairs:
        return None, "Solana işlem çifti bulunamadı."
    pair = max(pairs, key=lambda p: float((p.get("liquidity") or {}).get("usd") or 0))
    price = float(pair.get("priceUsd") or 0)
    if price <= 0:
        return None, "Geçerli fiyat verisi yok."
    return price, None

def log_trade(state, side, price, tokens, sol_amount, note):
    state["trades"].append({
        "time": datetime.now(timezone.utc).isoformat(),
        "side": side,
        "price_usd": price,
        "tokens": tokens,
        "sol_amount": sol_amount,
        "note": note
    })

def main():
    state = load_state()
    print("Pump.fun PAPER TRADING — gerçek emir gönderilmez.")
    print(f"Mint: {MINT}")
    print(f"Sanal bakiye: {state['cash_sol']:.6f} SOL")
    print("Fiyat verisi bekleniyor. Durdurmak için Ctrl+C.\n")

    while True:
        try:
            price, error = get_price()
            if error:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] {error}")
                time.sleep(POLL_SECONDS)
                continue

            state["last_price_usd"] = price
            pos = state["position_tokens"]

            if pos <= 0 and state["cash_sol"] >= TRADE_SIZE_SOL:
                # İlk sürümde seçilen coinde bir kez sanal giriş yapar.
                # Gerçek alış emri/özel anahtar/cüzdan bağlantısı yoktur.
                sol_usd = requests.get(
                    "https://api.coinbase.com/v2/prices/SOL-USD/spot", timeout=10
                ).json()["data"]["amount"]
                sol_usd = float(sol_usd)
                entry_usd = price
                token_qty = (TRADE_SIZE_SOL * sol_usd) / entry_usd
                state["cash_sol"] -= TRADE_SIZE_SOL
                state["position_tokens"] = token_qty
                state["entry_price_usd"] = entry_usd
                state["entry_cost_sol"] = TRADE_SIZE_SOL
                log_trade(state, "PAPER BUY", price, token_qty, TRADE_SIZE_SOL,
                          "Sanal giriş; ücret/slippage dahil değildir.")
                print(f"SANAL ALIM | fiyat ${price:.10f} | {token_qty:.4f} token")
            elif pos > 0:
                entry = state["entry_price_usd"]
                change = ((price / entry) - 1) * 100
                print(f"Fiyat ${price:.10f} | pozisyon değişimi {change:+.2f}%")
                if change >= TAKE_PROFIT_PCT or change <= -STOP_LOSS_PCT:
                    sol_usd = float(requests.get(
                        "https://api.coinbase.com/v2/prices/SOL-USD/spot", timeout=10
                    ).json()["data"]["amount"])
                    proceeds_sol = (pos * price) / sol_usd
                    state["cash_sol"] += proceeds_sol
                    side = "PAPER SELL"
                    note = "Take profit" if change >= TAKE_PROFIT_PCT else "Stop loss"
                    log_trade(state, side, price, pos, proceeds_sol,
                              f"{note}; ücret/slippage dahil değildir.")
                    print(f"SANAL SATIŞ | {note} | sonuç {change:+.2f}%")
                    state["position_tokens"] = 0.0
                    state["entry_price_usd"] = None
                    state["entry_cost_sol"] = 0.0
                    print(f"Güncel sanal nakit: {state['cash_sol']:.6f} SOL")

            save_state(state)
            time.sleep(POLL_SECONDS)

        except KeyboardInterrupt:
            save_state(state)
            print("\nBot durduruldu. Sanal durum kaydedildi.")
            break
        except Exception as exc:
            print(f"Hata: {exc}")
            time.sleep(POLL_SECONDS)

if __name__ == "__main__":
    main()
