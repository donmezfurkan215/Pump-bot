# Pump.fun Paper Trading Bot

Bu proje yalnızca **sanal işlem simülasyonudur**. Gerçek Solana işlemi göndermez, cüzdan bağlamaz ve private key istemez.

## Varsayılan ayarlar
- İzlenen mint: `Fksnpd6PPR87sCUXe2F8xqJgzAVnRBXfjsVxYZqqpump`
- Sanal başlangıç bakiyesi: 1 SOL
- Sanal giriş: 0.01 SOL
- Take profit: +30%
- Stop loss: -15%
- Fiyat kontrolü: 15 saniyede bir

## Codespaces'te çalıştırma
Terminalde:

```bash
pip install -r requirements.txt
python bot.py
```

Durdurmak için `Ctrl+C`.

## Önemli sınırlamalar
- Fiyat DexScreener'dan, SOL/USD Coinbase spot fiyatından okunur.
- API verisi gecikebilir veya token için henüz pair bulunmayabilir.
- İlk sürüm ilk uygun fiyatı gördüğünde bir kez sanal giriş yapar.
- Gerçek işlem ücretleri, slippage, bonding-curve fiyat farkı ve MEV etkileri modellenmez.
- Bu nedenle sonuçlar gerçek alım-satım performansını temsil etmez.
